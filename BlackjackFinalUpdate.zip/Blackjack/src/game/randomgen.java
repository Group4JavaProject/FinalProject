package game;

import java.util.Random;   // random import

public class randomgen {
	
	static int cardRandom1,cardRandom2,cardRandom3,cardRandom4,cardRandom5,cardRandom6,cardRandom7,cardRandom8,suitRandom1,suitRandom2,suitRandom3,suitRandom4,suitRandom5,suitRandom6,suitRandom7,suitRandom8;

	public void randomCard1(int cardRandom1) {
		this.cardRandom1 = cardRandom1;
	}public void randomCard2(int cardRandom2) {
		this.cardRandom2 = cardRandom2;
	}public void randomCard3(int cardRandom3) {
		this.cardRandom3 = cardRandom3;
	}public void randomCard4(int cardRandom4) {
		this.cardRandom4 = cardRandom4;
	}public void randomCard5(int cardRandom5) {
		this.cardRandom5 = cardRandom5;
	}public void randomCard6(int cardRandom6) {
		this.cardRandom6 = cardRandom6;
	}public void randomCard7(int cardRandom7) {
		this.cardRandom7 = cardRandom7;
	}public void randomCard8(int cardRandom8) {
		this.cardRandom8 = cardRandom8;
	}public void randomSuit1(int suitRandom1) {
		this.suitRandom1 = suitRandom1;
	}public void randomSuit2(int suitRandom2) {
		this.suitRandom2 = suitRandom2;
	}public void randomSuit3(int suitRandom3) {
		this.suitRandom3 = suitRandom3;
	}public void randomSuit4(int suitRandom4) {
		this.suitRandom4 = suitRandom4;
	}public void randomSuit5(int suitRandom5) {
		this.suitRandom5 = suitRandom5;
	}public void randomSuit6(int suitRandom6) {
		this.suitRandom6 = suitRandom6;
	}public void randomSuit7(int suitRandom7) {
		this.suitRandom7 = suitRandom7;
	}public void randomSuit8(int suitRandom8) {
		this.suitRandom8 = suitRandom8;
	}

		int cardRandInt1() {
		Random cardValue1 = new Random(); // random dealer card #1
		int cardRandom1 = cardValue1.nextInt(1, 14);
		//Ace, 2, 3, 4, 5, 6, 7, 8, 9, 10, Jack , Queen, King (nums and associated vals)
		//1  , 2, 3, 4, 5, 6, 7, 8, 9. 10, 10   , 10   , 10
		randomgen randomgen = new randomgen();
		randomgen.randomCard1(cardRandom1);
		return(cardRandom1);	
		}
	
		int suitRandInt1() {
		Random suitValue1 = new Random();
		int suitRandom1 = suitValue1.nextInt(1, 5);
		//Clubs, Diamonds, Hearts, Spades (suits and associated vals)
		//1    , 2       , 3     , 4
		randomgen randomgen = new randomgen();
		randomgen.randomSuit1(suitRandom1);
		return(suitRandom1);
		}
			
		String cardRandStr1() {	
		String cardValDealer1str = "";
		if (randomgen.cardRandom1 == 1) {  //assigns value to each number
		cardValDealer1str = "Ace"; // 11
			} else if (randomgen.cardRandom1 == 2) {
		cardValDealer1str = "Two"; // 2
			} else if (randomgen.cardRandom1 == 3) {
		cardValDealer1str = "Three"; // 3
			} else if (randomgen.cardRandom1 == 4) {
		cardValDealer1str = "Four"; // 4
			} else if (randomgen.cardRandom1 == 5) {
		cardValDealer1str = "Five"; // 5
			} else if (randomgen.cardRandom1 == 6) {
		cardValDealer1str = "Six"; // 6
			} else if (randomgen.cardRandom1 == 7) {
		cardValDealer1str = "Seven"; // 7
			} else if (randomgen.cardRandom1 == 8) {
		cardValDealer1str = "Eight"; // 8
			} else if (randomgen.cardRandom1 == 9) {
		cardValDealer1str = "Nine"; // 9
			} else if (randomgen.cardRandom1 == 10) {
		cardValDealer1str = "Ten"; // 10
			} else if (randomgen.cardRandom1 == 11) {
		cardValDealer1str = "Jack"; // 10
			} else if (randomgen.cardRandom1 == 12) {
		cardValDealer1str = "Queen"; // 10
			} else {
		cardValDealer1str = "King";  // 10 
			}
		return(cardValDealer1str);
	}

		String suitRandStr1() {
		String suitDealer1str = "";
		if (suitRandom1 == 1) {  //assigns suit to each number
		suitDealer1str = "Clubs"; // 1
			} else if (suitRandom1 == 2) {
		suitDealer1str = "Diamonds"; // 2
			} else if (suitRandom1 == 3) {
		suitDealer1str = "Hearts"; // 3
			} else {
		suitDealer1str = "Spades"; // 4
			}
		return(suitDealer1str);
	}
		
		int cardRandInt2() {
		Random cardValue2 = new Random(); // random dealer card #2
		int cardRandom2 = cardValue2.nextInt(1, 14);
		//Ace, 2, 3, 4, 5, 6, 7, 8, 9, 10, Jack , Queen, King (nums and associated vals)
		//1  , 2, 3, 4, 5, 6, 7, 8, 9. 10, 10   , 10   , 10
		randomgen randomgen = new randomgen();
		randomgen.randomCard2(cardRandom2);
		return(cardRandom2);	
		}
	
		int suitRandInt2() {
		Random suitValue2 = new Random();
		int suitRandom2 = suitValue2.nextInt(1, 5);
		//Clubs, Diamonds, Hearts, Spades (suits and associated vals)
		//1    , 2       , 3     , 4
		randomgen randomgen = new randomgen();
		randomgen.randomSuit2(suitRandom2);
		return(suitRandom2);
		}
			
		String cardRandStr2() {	
		String cardValDealer2str = "";
		if (randomgen.cardRandom2 == 1) {  //assigns value to each number
		cardValDealer2str = "Ace"; // 11
			} else if (randomgen.cardRandom2 == 2) {
		cardValDealer2str = "Two"; // 2
			} else if (randomgen.cardRandom2 == 3) {
		cardValDealer2str = "Three"; // 3
			} else if (randomgen.cardRandom2 == 4) {
		cardValDealer2str = "Four"; // 4
			} else if (randomgen.cardRandom2 == 5) {
		cardValDealer2str = "Five"; // 5
			} else if (randomgen.cardRandom2 == 6) {
		cardValDealer2str = "Six"; // 6
			} else if (randomgen.cardRandom2 == 7) {
		cardValDealer2str = "Seven"; // 7
			} else if (randomgen.cardRandom2 == 8) {
		cardValDealer2str = "Eight"; // 8
			} else if (randomgen.cardRandom2 == 9) {
		cardValDealer2str = "Nine"; // 9
			} else if (randomgen.cardRandom2 == 10) {
		cardValDealer2str = "Ten"; // 10
			} else if (randomgen.cardRandom2 == 11) {
		cardValDealer2str = "Jack"; // 10
			} else if (randomgen.cardRandom2 == 12) {
		cardValDealer2str = "Queen"; // 10
			} else {
		cardValDealer2str = "King";  // 10 
			}
		return(cardValDealer2str);
		}

		String suitRandStr2() {
		String suitDealer2str = "";
		if (suitRandom2 == 1) {  //assigns suit to each number
		suitDealer2str = "Clubs"; // 1
			} else if (suitRandom2 == 2) {
		suitDealer2str = "Diamonds"; // 2
			} else if (suitRandom2 == 3) {
		suitDealer2str = "Hearts"; // 3
			} else {
		suitDealer2str = "Spades"; // 4
			}
		return(suitDealer2str);
		}

		int cardRandInt3() {
		Random cardValue3 = new Random(); // random dealer card #3
		int cardRandom3 = cardValue3.nextInt(1, 14);
		//Ace, 2, 3, 4, 5, 6, 7, 8, 9, 10, Jack , Queen, King (nums and associated vals)
		//1  , 2, 3, 4, 5, 6, 7, 8, 9. 10, 10   , 10   , 10
		randomgen randomgen = new randomgen();
		randomgen.randomCard3(cardRandom3);
		return(cardRandom3);	
		}
		
		int suitRandInt3() {
		Random suitValue3 = new Random();
		int suitRandom3 = suitValue3.nextInt(1, 5);
		//Clubs, Diamonds, Hearts, Spades (suits and associated vals)
		//1    , 2       , 3     , 4
		randomgen randomgen = new randomgen();
		randomgen.randomSuit3(suitRandom3);
		return(suitRandom3);
		}
			
		String cardRandStr3() {	
		String cardValDealer3str = "";
		if (randomgen.cardRandom3 == 1) {  //assigns value to each number
		cardValDealer3str = "Ace"; // 11
			} else if (randomgen.cardRandom3 == 2) {
		cardValDealer3str = "Two"; // 2
			} else if (randomgen.cardRandom3 == 3) {
		cardValDealer3str = "Three"; // 3
			} else if (randomgen.cardRandom3 == 4) {
		cardValDealer3str = "Four"; // 4
			} else if (randomgen.cardRandom3 == 5) {
		cardValDealer3str = "Five"; // 5
			} else if (randomgen.cardRandom3 == 6) {
		cardValDealer3str = "Six"; // 6
			} else if (randomgen.cardRandom3 == 7) {
		cardValDealer3str = "Seven"; // 7
			} else if (randomgen.cardRandom3 == 8) {
		cardValDealer3str = "Eight"; // 8
			} else if (randomgen.cardRandom3 == 9) {
		cardValDealer3str = "Nine"; // 9
			} else if (randomgen.cardRandom3 == 10) {
		cardValDealer3str = "Ten"; // 10
			} else if (randomgen.cardRandom3 == 11) {
		cardValDealer3str = "Jack"; // 10
			} else if (randomgen.cardRandom3 == 12) {
		cardValDealer3str = "Queen"; // 10
			} else {
		cardValDealer3str = "King";  // 10 
			}
		return(cardValDealer3str);
		}

		String suitRandStr3() {
		String suitDealer3str = "";
		if (suitRandom3 == 1) {  //assigns suit to each number
		suitDealer3str = "Clubs"; // 1
			} else if (suitRandom3 == 2) {
		suitDealer3str = "Diamonds"; // 2
			} else if (suitRandom3 == 3) {
		suitDealer3str = "Hearts"; // 3
			} else {
		suitDealer3str = "Spades"; // 4
			}
		return(suitDealer3str);
		}
		
		int cardRandInt4() {
		Random cardValue4 = new Random(); // random dealer card #4
		int cardRandom4 = cardValue4.nextInt(1, 14);
		//Ace, 2, 3, 4, 5, 6, 7, 8, 9, 10, Jack , Queen, King (nums and associated vals)
		//1  , 2, 3, 4, 5, 6, 7, 8, 9. 10, 10   , 10   , 10
		randomgen randomgen = new randomgen();
		randomgen.randomCard4(cardRandom4);
		return(cardRandom4);	
		}
		
		int suitRandInt4() {
		Random suitValue4 = new Random();
		int suitRandom4 = suitValue4.nextInt(1, 5);
		//Clubs, Diamonds, Hearts, Spades (suits and associated vals)
		//1    , 2       , 3     , 4
		randomgen randomgen = new randomgen();
		randomgen.randomSuit4(suitRandom4);
		return(suitRandom4);
		}
			
		String cardRandStr4() {	
		String cardValDealer4str = "";
		if (randomgen.cardRandom4 == 1) {  //assigns value to each number
		cardValDealer4str = "Ace"; // 11
			} else if (randomgen.cardRandom4 == 2) {
		cardValDealer4str = "Two"; // 2
			} else if (randomgen.cardRandom4 == 3) {
		cardValDealer4str = "Three"; // 3
			} else if (randomgen.cardRandom4 == 4) {
		cardValDealer4str = "Four"; // 4
			} else if (randomgen.cardRandom4 == 5) {
		cardValDealer4str = "Five"; // 5
			} else if (randomgen.cardRandom4 == 6) {
		cardValDealer4str = "Six"; // 6
			} else if (randomgen.cardRandom4 == 7) {
		cardValDealer4str = "Seven"; // 7
			} else if (randomgen.cardRandom4 == 8) {
		cardValDealer4str = "Eight"; // 8
			} else if (randomgen.cardRandom4 == 9) {
		cardValDealer4str = "Nine"; // 9
			} else if (randomgen.cardRandom4 == 10) {
		cardValDealer4str = "Ten"; // 10
			} else if (randomgen.cardRandom4 == 11) {
		cardValDealer4str = "Jack"; // 10
			} else if (randomgen.cardRandom4 == 12) {
		cardValDealer4str = "Queen"; // 10
			} else {
		cardValDealer4str = "King";  // 10 
			}
		return(cardValDealer4str);
		}

		String suitRandStr4() {
		String suitDealer4str = "";
		if (suitRandom4 == 1) {  //assigns suit to each number
		suitDealer4str = "Clubs"; // 1
			} else if (suitRandom4 == 2) {
		suitDealer4str = "Diamonds"; // 2
			} else if (suitRandom4 == 3) {
		suitDealer4str = "Hearts"; // 3
			} else {
		suitDealer4str = "Spades"; // 4
			}
		return(suitDealer4str);
		}
		
		int cardRandInt5() {
		Random cardValue5 = new Random(); // random dealer card #1
		int cardRandom5 = cardValue5.nextInt(1, 14);
		//Ace, 2, 3, 4, 5, 6, 7, 8, 9, 10, Jack , Queen, King (nums and associated vals)
		//1  , 2, 3, 4, 5, 6, 7, 8, 9. 10, 10   , 10   , 10
		randomgen randomgen = new randomgen();
		randomgen.randomCard5(cardRandom5);
		return(cardRandom5);	
		}
	
		int suitRandInt5() {
		Random suitValue5 = new Random();
		int suitRandom5 = suitValue5.nextInt(1, 5);
		//Clubs, Diamonds, Hearts, Spades (suits and associated vals)
		//1    , 2       , 3     , 4
		randomgen randomgen = new randomgen();
		randomgen.randomSuit5(suitRandom5);
		return(suitRandom5);
		}
			
		String cardRandStr5() {	
		String cardValPlayer1str = "";
		if (randomgen.cardRandom5 == 1) {  //assigns value to each number
		cardValPlayer1str = "Ace"; // 11
			} else if (randomgen.cardRandom5 == 2) {
		cardValPlayer1str = "Two"; // 2
			} else if (randomgen.cardRandom5 == 3) {
		cardValPlayer1str = "Three"; // 3
			} else if (randomgen.cardRandom5 == 4) {
		cardValPlayer1str = "Four"; // 4
			} else if (randomgen.cardRandom5 == 5) {
		cardValPlayer1str = "Five"; // 5
			} else if (randomgen.cardRandom5 == 6) {
		cardValPlayer1str = "Six"; // 6
			} else if (randomgen.cardRandom5 == 7) {
		cardValPlayer1str = "Seven"; // 7
			} else if (randomgen.cardRandom5 == 8) {
		cardValPlayer1str = "Eight"; // 8
			} else if (randomgen.cardRandom5 == 9) {
		cardValPlayer1str = "Nine"; // 9
			} else if (randomgen.cardRandom5 == 10) {
		cardValPlayer1str = "Ten"; // 10
			} else if (randomgen.cardRandom5 == 11) {
		cardValPlayer1str = "Jack"; // 10
			} else if (randomgen.cardRandom5 == 12) {
		cardValPlayer1str = "Queen"; // 10
			} else {
		cardValPlayer1str = "King";  // 10 
			}
		return(cardValPlayer1str);
	}

		String suitRandStr5() {
		String suitPlayer1str = "";
		if (suitRandom5 == 1) {  //assigns suit to each number
		suitPlayer1str = "Clubs"; // 1
			} else if (suitRandom5 == 2) {
		suitPlayer1str = "Diamonds"; // 2
			} else if (suitRandom5 == 3) {
		suitPlayer1str = "Hearts"; // 3
			} else {
		suitPlayer1str = "Spades"; // 4
			}
		return(suitPlayer1str);	
		}
		
		int cardRandInt6() {
		Random cardValue6 = new Random(); // random dealer card #1
		int cardRandom6 = cardValue6.nextInt(1, 14);
		//Ace, 2, 3, 4, 5, 6, 7, 8, 9, 10, Jack , Queen, King (nums and associated vals)
		//1  , 2, 3, 4, 5, 6, 7, 8, 9. 10, 10   , 10   , 10
		randomgen randomgen = new randomgen();
		randomgen.randomCard6(cardRandom6);
		return(cardRandom6);	
		}
	
		int suitRandInt6() {
		Random suitValue6 = new Random();
		int suitRandom6 = suitValue6.nextInt(1, 5);
		//Clubs, Diamonds, Hearts, Spades (suits and associated vals)
		//1    , 2       , 3     , 4
		randomgen randomgen = new randomgen();
		randomgen.randomSuit6(suitRandom6);
		return(suitRandom6);
		}
			
		String cardRandStr6() {	
		String cardValPlayer2str = "";
		if (randomgen.cardRandom6 == 1) {  //assigns value to each number
		cardValPlayer2str = "Ace"; // 11
			} else if (randomgen.cardRandom6 == 2) {
		cardValPlayer2str = "Two"; // 2
			} else if (randomgen.cardRandom6 == 3) {
		cardValPlayer2str = "Three"; // 3
			} else if (randomgen.cardRandom6 == 4) {
		cardValPlayer2str = "Four"; // 4
			} else if (randomgen.cardRandom6 == 5) {
		cardValPlayer2str = "Five"; // 5
			} else if (randomgen.cardRandom6 == 6) {
		cardValPlayer2str = "Six"; // 6
			} else if (randomgen.cardRandom6 == 7) {
		cardValPlayer2str = "Seven"; // 7
			} else if (randomgen.cardRandom6 == 8) {
		cardValPlayer2str = "Eight"; // 8
			} else if (randomgen.cardRandom6 == 9) {
		cardValPlayer2str = "Nine"; // 9
			} else if (randomgen.cardRandom6 == 10) {
		cardValPlayer2str = "Ten"; // 10
			} else if (randomgen.cardRandom6 == 11) {
		cardValPlayer2str = "Jack"; // 10
			} else if (randomgen.cardRandom6 == 12) {
		cardValPlayer2str = "Queen"; // 10
			} else {
		cardValPlayer2str = "King";  // 10 
			}
		return(cardValPlayer2str);
	}

		String suitRandStr6() {
		String suitPlayer2str = "";
		if (suitRandom6 == 1) {  //assigns suit to each number
		suitPlayer2str = "Clubs"; // 1
			} else if (suitRandom6 == 2) {
		suitPlayer2str = "Diamonds"; // 2
			} else if (suitRandom6 == 3) {
		suitPlayer2str = "Hearts"; // 3
			} else {
		suitPlayer2str = "Spades"; // 4
			}
		return(suitPlayer2str);
		}
		
		int cardRandInt7() {
		Random cardValue7 = new Random(); // random dealer card #1
		int cardRandom7 = cardValue7.nextInt(1, 14);
		//Ace, 2, 3, 4, 5, 6, 7, 8, 9, 10, Jack , Queen, King (nums and associated vals)
		//1  , 2, 3, 4, 5, 6, 7, 8, 9. 10, 10   , 10   , 10
		randomgen randomgen = new randomgen();
		randomgen.randomCard7(cardRandom7);
		return(cardRandom7);	
		}
	
		int suitRandInt7() {
		Random suitValue7 = new Random();
		int suitRandom7 = suitValue7.nextInt(1, 5);
		//Clubs, Diamonds, Hearts, Spades (suits and associated vals)
		//1    , 2       , 3     , 4
		randomgen randomgen = new randomgen();
		randomgen.randomSuit7(suitRandom7);
		return(suitRandom7);
		}
			
		String cardRandStr7() {	
		String cardValPlayer3str = "";
		if (randomgen.cardRandom7 == 1) {  //assigns value to each number
		cardValPlayer3str = "Ace"; // 11
			} else if (randomgen.cardRandom7 == 2) {
		cardValPlayer3str = "Two"; // 2
			} else if (randomgen.cardRandom7 == 3) {
		cardValPlayer3str = "Three"; // 3
			} else if (randomgen.cardRandom7 == 4) {
		cardValPlayer3str = "Four"; // 4
			} else if (randomgen.cardRandom7 == 5) {
		cardValPlayer3str = "Five"; // 5
			} else if (randomgen.cardRandom7 == 6) {
		cardValPlayer3str = "Six"; // 6
			} else if (randomgen.cardRandom7 == 7) {
		cardValPlayer3str = "Seven"; // 7
			} else if (randomgen.cardRandom7 == 8) {
		cardValPlayer3str = "Eight"; // 8
			} else if (randomgen.cardRandom7 == 9) {
		cardValPlayer3str = "Nine"; // 9
			} else if (randomgen.cardRandom7 == 10) {
		cardValPlayer3str = "Ten"; // 10
			} else if (randomgen.cardRandom7 == 11) {
		cardValPlayer3str = "Jack"; // 10
			} else if (randomgen.cardRandom7 == 12) {
		cardValPlayer3str = "Queen"; // 10
			} else {
		cardValPlayer3str = "King";  // 10 
			}
		return(cardValPlayer3str);
		}

		String suitRandStr7() {
		String suitPlayer3str = "";
		if (suitRandom7 == 1) {  //assigns suit to each number
		suitPlayer3str = "Clubs"; // 1
			} else if (suitRandom7 == 2) {
		suitPlayer3str = "Diamonds"; // 2
			} else if (suitRandom7 == 3) {
		suitPlayer3str = "Hearts"; // 3
			} else {
		suitPlayer3str = "Spades"; // 4
			}
		return(suitPlayer3str);
		}	
		
		int cardRandInt8() {
		Random cardValue8 = new Random(); // random dealer card #1
		int cardRandom8 = cardValue8.nextInt(1, 14);
		//Ace, 2, 3, 4, 5, 6, 7, 8, 9, 10, Jack , Queen, King (nums and associated vals)
		//1  , 2, 3, 4, 5, 6, 7, 8, 9. 10, 10   , 10   , 10
		randomgen randomgen = new randomgen();
		randomgen.randomCard8(cardRandom8);
		return(cardRandom8);	
		}
	
		int suitRandInt8() {
		Random suitValue8 = new Random();
		int suitRandom8 = suitValue8.nextInt(1, 5);
		//Clubs, Diamonds, Hearts, Spades (suits and associated vals)
		//1    , 2       , 3     , 4
		randomgen randomgen = new randomgen();
		randomgen.randomSuit8(suitRandom8);
		return(suitRandom8);
		}
			
		String cardRandStr8() {	
		String cardValPlayer4str = "";
		if (randomgen.cardRandom8 == 1) {  //assigns value to each number
		cardValPlayer4str = "Ace"; // 11
			} else if (randomgen.cardRandom8 == 2) {
		cardValPlayer4str = "Two"; // 2
			} else if (randomgen.cardRandom8 == 3) {
		cardValPlayer4str = "Three"; // 3
			} else if (randomgen.cardRandom8 == 4) {
		cardValPlayer4str = "Four"; // 4
			} else if (randomgen.cardRandom8 == 5) {
		cardValPlayer4str = "Five"; // 5
			} else if (randomgen.cardRandom8 == 6) {
		cardValPlayer4str = "Six"; // 6
			} else if (randomgen.cardRandom8 == 7) {
		cardValPlayer4str = "Seven"; // 7
			} else if (randomgen.cardRandom8 == 8) {
		cardValPlayer4str = "Eight"; // 8
			} else if (randomgen.cardRandom8 == 9) {
		cardValPlayer4str = "Nine"; // 9
			} else if (randomgen.cardRandom8 == 10) {
		cardValPlayer4str = "Ten"; // 10
			} else if (randomgen.cardRandom8 == 11) {
		cardValPlayer4str = "Jack"; // 10
			} else if (randomgen.cardRandom8 == 12) {
		cardValPlayer4str = "Queen"; // 10
			} else {
		cardValPlayer4str = "King";  // 10 
			}
		return(cardValPlayer4str);
	}

		String suitRandStr8() {
		String suitPlayer4str = "";
		if (suitRandom8 == 1) {  //assigns suit to each number
		suitPlayer4str = "Clubs"; // 1
			} else if (suitRandom8 == 2) {
		suitPlayer4str = "Diamonds"; // 2
			} else if (suitRandom8 == 3) {
		suitPlayer4str = "Hearts"; // 3
			} else {
		suitPlayer4str = "Spades"; // 4
			}
		return(suitPlayer4str);
		}	
		
}
