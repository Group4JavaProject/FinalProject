package game;

import java.util.Random;

public class dealerArray {

	public void dArr() {
		String[] array1 = {"Dave", "Chris", "Bob", "Steven", "Charles"};		// our string array selects from predetermined dealer names to make the game more realistic
		Random dealer = new Random();				// randomizes the value to be picked from the array
		int dealerNum = dealer.nextInt(0, 5);
		System.out.println(array1[dealerNum] + " is your dealer for this round.");		//uses the random value selected to pull dealer name for round
	}

}
