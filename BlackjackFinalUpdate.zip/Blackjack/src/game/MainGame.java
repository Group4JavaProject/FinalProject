package game;     // Made by Camden, Lauren, Tyler

import java.util.Scanner; //imports scanner for user input

public class MainGame {
		
	String creator1,creator2,creator3;   // Constructors in this area

	static boolean boolContinue;
	
	public MainGame() {
		creator1 = "Camden";   // constants, these will not change in the program
		creator2 = "Lauren";
		creator3 = "Tyler";	
	}
	
	public static void main(String[] args) throws InterruptedException { // throws inturruptedException is to allow for Thread.sleep (used to give player time to read - waits)
		formatting format1 = new formatting();   // connects format class to ease clutter
		rules text = new rules();   // connects rules from rules class
		dealerArray names = new dealerArray();  // connects dealer array from dealerArray class
		
		Scanner userInput = new Scanner(System.in);
		System.out.println("Type P or Play to Begin Blackjack\n" + "Or type R or Rules to read the rules of Blackjack");  // play scanner to decide to play or  to go to rules
		String userInputString = userInput.nextLine();

	if (userInputString.equalsIgnoreCase("p") || userInputString.equalsIgnoreCase("play")) {
		System.out.println("The game is now starting");
		format1.design1();   // section separator
		Thread.sleep(3000);
		boolContinue = true;
	} else if (userInputString.equalsIgnoreCase("r") || userInputString.equalsIgnoreCase("rules")) {   //game rules
		text.print();				// prints rules from rules class
		Thread.sleep(30000); //waits
		boolContinue = true;
	} else {
		System.out.println("invalid, restart game");  // invalid with exit
		System.exit(0);
	}
	if (boolContinue = true) {
		names.dArr(); // calls dealer array class 
		format1.design1();   // section separator
	
		randomgen dealerCard1 = new randomgen();  //dealer #1 card called from randomgen class
		int cardRand1 = dealerCard1.cardRandInt1();
		if (cardRand1 == 11 || cardRand1 == 12 || cardRand1 == 13) {
			cardRand1 = 10;
		}if (cardRand1 == 1) {
			cardRand1 = 11;		//logic to fix face cards value
		}
		randomgen dealerSuit1 = new randomgen();		//this section grabs data from randomgen class, includes suit string, value string, and value int
		int suitRand1 = dealerSuit1.suitRandInt1();		// assigns them to variables used in logic of main class
		randomgen cardString1 = new randomgen();
		String cardValDealer1 = cardString1.cardRandStr1();
		randomgen suitString1 = new randomgen();
		String suitDealer1 = suitString1.suitRandStr1();
		
		randomgen dealerCard2 = new randomgen();  //dealer #2 card called from randomgen class
		int cardRand2 = dealerCard2.cardRandInt2();
		if (cardRand2 == 11 || cardRand2 == 12 || cardRand2 == 13) {
			cardRand2 = 10;
		}if (cardRand2 == 1) {
			cardRand2 = 11;		//logic to fix face cards value
		}
		randomgen dealerSuit2 = new randomgen();		//this section grabs data from randomgen class, includes suit string, value string, and value int
		int suitRand2 = dealerSuit2.suitRandInt2();		// assigns them to variables used in logic of main class
		randomgen cardString2 = new randomgen();
		String cardValDealer2 = cardString2.cardRandStr2();
		randomgen suitString2 = new randomgen();
		String suitDealer2 = suitString2.suitRandStr2();
		
		randomgen dealerCard3 = new randomgen();  //dealer #3 card called from randomgen class
		int cardRand3 = dealerCard3.cardRandInt3();
		if (cardRand3 == 11 || cardRand3 == 12 || cardRand3 == 13) {
			cardRand3 = 10;   
		}if (cardRand3 == 1) {
			cardRand3 = 11;		//logic to fix face cards value
		}
		randomgen dealerSuit3 = new randomgen();		//this section grabs data from randomgen class, includes suit string, value string, and value int
		int suitRand3 = dealerSuit3.suitRandInt3();		// assigns them to variables used in logic of main class
		randomgen cardString3 = new randomgen();
		String cardValDealer3 = cardString3.cardRandStr3();
		randomgen suitString3 = new randomgen();
		String suitDealer3 = suitString3.suitRandStr3();
		
		randomgen dealerCard4 = new randomgen();  //dealer #4 card called from randomgen class
		int cardRand4 = dealerCard4.cardRandInt4();
		if (cardRand4 == 11 || cardRand4 == 12 || cardRand4 == 13) {
			cardRand4 = 10;
		}if (cardRand4 == 1) {
			cardRand4 = 11;		//logic to fix face cards value
		}
		randomgen dealerSuit4 = new randomgen();		//this section grabs data from randomgen class, includes suit string, value string, and value int
		int suitRand4 = dealerSuit4.suitRandInt4();		// assigns them to variables used in logic of main class
		randomgen cardString4 = new randomgen();
		String cardValDealer4 = cardString4.cardRandStr4();
		randomgen suitString4 = new randomgen();
		String suitDealer4 = suitString4.suitRandStr4();

		randomgen playerCard1 = new randomgen();  //player #1 card called from randomgen class
		int cardRand5 = playerCard1.cardRandInt5();
		if (cardRand5 == 11 || cardRand5 == 12 || cardRand5 == 13) {
			cardRand5 = 10;
		}if (cardRand5 == 1) {
			cardRand5 = 11;		//logic to fix face cards value
		}
		randomgen playerSuit1 = new randomgen();  		//this section grabs data from randomgen class, includes suit string, value string, and value int
		int suitRand5 = playerSuit1.suitRandInt5();		// assigns them to variables used in logic of main class
		randomgen cardString5 = new randomgen();
		String cardValPlayer1 = cardString5.cardRandStr5();
		randomgen suitString5 = new randomgen();
		String suitPlayer1 = suitString5.suitRandStr5();
		
		randomgen playerCard2 = new randomgen();	//player #2 card called from randomgen class
		int cardRand6 = playerCard2.cardRandInt6();
		if (cardRand6 == 11 || cardRand6 == 12 || cardRand6 == 13) {
			cardRand6 = 10;
		}if (cardRand6 == 1) {
			cardRand6 = 11;		//logic to fix face cards value
		}
		randomgen playerSuit2 = new randomgen();  		//this section grabs data from randomgen class, includes suit string, value string, and value int
		int suitRand6 = playerSuit2.suitRandInt6();		// assigns them to variables used in logic of main class
		randomgen cardString6 = new randomgen();
		String cardValPlayer2 = cardString6.cardRandStr6();
		randomgen suitString6 = new randomgen();
		String suitPlayer2 = suitString6.suitRandStr6();
		
		randomgen playerCard3 = new randomgen();	//player #3 card called from randomgen class
		int cardRand7 = playerCard3.cardRandInt7();
		if (cardRand7 == 11 || cardRand7 == 12 || cardRand7 == 13) {
			cardRand7 = 10;
		}if (cardRand7 == 1) {
			cardRand7 = 11;		//logic to fix face cards value
		}
		randomgen playerSuit3 = new randomgen();		//this section grabs data from randomgen class, includes suit string, value string, and value int
		int suitRand7 = playerSuit3.suitRandInt7();		// assigns them to variables used in logic of main class
		randomgen cardString7 = new randomgen();
		String cardValPlayer3 = cardString7.cardRandStr7();
		randomgen suitString7 = new randomgen();
		String suitPlayer3 = suitString7.suitRandStr7();
		
		randomgen playerCard4 = new randomgen();	//player #4 card called from randomgen cla
		int cardRand8 = playerCard4.cardRandInt8();
		if (cardRand8 == 11 || cardRand8 == 12 || cardRand8 == 13) {
			cardRand8 = 10;
		}if (cardRand8 == 1) {
			cardRand8 = 11;		//logic to fix face cards value
		}
		randomgen playerSuit4 = new randomgen();		//this section grabs data from randomgen class, includes suit string, value string, and value int
		int suitRand8 = playerSuit4.suitRandInt8();		// assigns them to variables used in logic of main class
		randomgen cardString8 = new randomgen();
		String cardValPlayer4 = cardString8.cardRandStr8();
		randomgen suitString8 = new randomgen();
		String suitPlayer4 = suitString8.suitRandStr8();
		
		// player logic below
		int playerTwoCardTotal = cardRand5 + cardRand6;
		int playerThreeCardTotal = cardRand5 + cardRand6 + cardRand7;
		int playerFourCardTotal = cardRand5 + cardRand6 + cardRand7 + cardRand8;  // all combos for player		
		
		System.out.println("The dealer's first card is a: " + cardValDealer1 + " of " + suitDealer1);  // tells user their cards and asks what they want to do
		System.out.println("His second card is hidden");
		Thread.sleep(3500); //waits
		format1.design1();   // section separator
		System.out.println("He is now dealing your cards.");
		Thread.sleep(3500); //waits
		System.out.println("Your first two cards are: " + cardValPlayer1 + " of " + suitPlayer1 + " and " + cardValPlayer2 + " of " + suitPlayer2);
		format1.design1();   // section separator
		Thread.sleep(3500); //waits
		System.out.println("Do you want to hit or stand? type below:");
		
		Scanner hitOrStay1 = new Scanner(System.in);    // asks user if they want to hit or stay after seeing first two cards
		System.out.println("Type H or Hit to hit again. \nType S or Stand or Stay to stand.");
		String hitOrStayUserInput1 = hitOrStay1.nextLine();
	
		int playerFinal = 0;
		boolean ifHitAgain = false;
		
		if (hitOrStayUserInput1.equalsIgnoreCase("S") || hitOrStayUserInput1.equalsIgnoreCase("Stand") || hitOrStayUserInput1.equalsIgnoreCase("Stay")) {   // reads user input for hit or stay and gives back result
			System.out.println(" ");
			System.out.println("You have decided to stand");
			format1.design1();   // section separator
			playerFinal = playerTwoCardTotal;
			
		} else if (hitOrStayUserInput1.equalsIgnoreCase("H") || hitOrStayUserInput1.equalsIgnoreCase("Hit")) {
			System.out.println(" ");
			System.out.println("You have decided to hit");
			ifHitAgain = true;
		} else {
			Thread.sleep(3500); //waits
			System.out.println("Restart game");   // invalid with exit
			System.exit(0);
		}if (ifHitAgain == true) {
			System.out.println("Your first three cards are: " + cardValPlayer1 + " of " + suitPlayer1 + " and " + cardValPlayer2 + " of " + suitPlayer2 + " and " + cardValPlayer3 + " of " + suitPlayer4);
		}if (playerThreeCardTotal > 21 && ifHitAgain == true) {   // logic if player ends up hitting for a 3rd card
			Thread.sleep(3500); //waits
			System.out.println("You have gone over 21, try again next time.");
			format1.design1();   // section separator
			playerFinal = 0;
		} else if (ifHitAgain == false) {
			Thread.sleep(3500); //waits
			System.out.println("Your total card value is worth: " + playerFinal);
			format1.design1();   // section separator
		} else {
			Scanner hitOrStay2 = new Scanner(System.in);
			System.out.println("Type H or Hit to hit again. \nType S or Stand or Stay to stand.");
			String hitOrStayUserInput2 = hitOrStay2.nextLine();	
			boolean ifHitAgain2 = false;
				
			if (hitOrStayUserInput2.equalsIgnoreCase("S") || hitOrStayUserInput2.equalsIgnoreCase("Stand") || hitOrStayUserInput2.equalsIgnoreCase("Stay")) {    // reads user input for hit or stay and gives back result
				System.out.println("You have decided to stand");
				playerFinal = playerThreeCardTotal;
			} else if (hitOrStayUserInput2.equalsIgnoreCase("H") || hitOrStayUserInput2.equalsIgnoreCase("Hit")) {
				System.out.println("You have decided to hit");
				ifHitAgain2 = true;
			} else {
				System.out.println("restart game");  // invalid with exit
				System.exit(0);
			}if(ifHitAgain2 == true) {
				System.out.println("Your first four cards are: " + cardValPlayer1 + " of " + suitString1 + " and " + cardValPlayer2 + " of " + suitPlayer2 + " and " + cardValPlayer3 + " of " + suitPlayer3 + " and " + cardValPlayer4 + " of " + suitPlayer4);
				playerFinal = playerFourCardTotal;
			}if (playerFourCardTotal > 21 && ifHitAgain2 == true) {    // logic if player ends up hitting for a 4th card
				System.out.println("You have gone over 21, try again next time.");
				playerFinal = 0;
			} else if (ifHitAgain2 == false) {
				System.out.println("Your total card value is worth: " + playerFinal);	
			} else {
				System.out.println("You must stand as the 4 Card limit is reached");
				playerFinal = playerFourCardTotal;
				System.out.println("Your total card value is worth: " + playerFinal);	
			}	
		}
		// dealer logic below
		int dealerTwoCardTotal = cardRand1 + cardRand2;;
		int dealerThreeCardTotal = cardRand1 + cardRand2 + cardRand3;
		int dealerFourCardTotal = cardRand1 + cardRand2 + cardRand3 + cardRand4;  // all combos for dealer		
		
		int dealerFinal = 0; // dealers final count
		boolean bust = false;
		Thread.sleep(3500); //waits
		format1.design1();   // section separator
		System.out.println("The dealer has revealed his second card");
		Thread.sleep(3500);  //waits
		System.out.println("His hand consists of a " + cardValDealer1 + " of " + suitDealer1 + " and a "  + cardValDealer2 + " of " + suitDealer2);	
		System.out.println(" ");
		
		if (dealerTwoCardTotal > 16 && dealerTwoCardTotal < 22) {    // decides if dealer stays at 2 cards, or busts, if within game parameters it will go to the next section to grab a 3rd card
			dealerFinal = dealerTwoCardTotal;
			Thread.sleep(3500); //waits
			System.out.println(" ");
			System.out.println("The dealer decided to stand");
		} else if (dealerTwoCardTotal > 21) {
			dealerFinal = 0;
			bust = true;
		} else {
			System.out.println(" ");
		}
			
		if (bust == false && dealerTwoCardTotal < 17) {	
			Thread.sleep(3500); //waits
			System.out.println("The dealer decided to hit again");
			Thread.sleep(3500); //waits
			System.out.println("His hand consists of a " + cardValDealer1 + " of " + suitDealer1 + " and a "  + cardValDealer2 + " of " + suitDealer2 + " and a "  + cardValDealer3 + " of " + suitDealer3);
			System.out.println(" ");
		}if (dealerThreeCardTotal > 16 && dealerThreeCardTotal < 22 && bust == false) {    // decides if dealer stays at 3 cards, or busts, if within game parameters it will go to the next section to grab a 4rd card
			dealerFinal = dealerThreeCardTotal;
			Thread.sleep(3500); //waits
			System.out.println(" ");
			System.out.println("The dealer decided to stand");
		} else if (dealerThreeCardTotal < 17 && bust == false) {
			dealerFinal = dealerFourCardTotal;
		} else if (dealerThreeCardTotal > 21 && dealerFinal == 0) {
			dealerFinal = 0;
			bust = true;
		} else {
			System.out.println(" ");
		}if (bust == false && dealerThreeCardTotal < 17) {	
			Thread.sleep(3500); //waits
			System.out.println(" ");
			System.out.println("The dealer decided to hit again");
			Thread.sleep(3500); //waits
			System.out.println("His hand consists of a " + cardValDealer1 + " of " + suitDealer1 + " and a "  + cardValDealer2 + " of " + suitDealer2 + " and a "  + cardValDealer3 + " of " + suitDealer3 + " and a "  + cardValDealer4 + " of " + suitDealer4);
		}if (dealerFourCardTotal > 16 && dealerFourCardTotal < 22 && bust == false) {    // decides if dealer stays at 4 cards, or busts
			dealerFinal = dealerFourCardTotal;
			Thread.sleep(3500); //waits
			System.out.println(" ");
			System.out.println("The dealer has reached his card limit, he must stand");
		} else if (dealerFourCardTotal < 17 && bust == false) {
			dealerFinal = dealerFourCardTotal;
			Thread.sleep(3500); //waits
			System.out.println(" ");
			System.out.println("The dealer has reached his card limit, he must stand");
		} else if (dealerFourCardTotal > 21 && dealerFinal == dealerFourCardTotal) { 
			dealerFinal = 0;
			bust = true;
		} else {
			System.out.println(" ");
		}if (dealerFinal == 21) {   // dealer blackjack
			Thread.sleep(3500); //waits
			System.out.println("The Dealer has recieved a Blackjack");
		}if (playerFinal == 21) {   // player blackjack
			Thread.sleep(3500); //waits
			System.out.println("The Player has recieved a Blackjack");
		}
		
		System.out.println(" ");
		while (bust == true) {   // while loop to determine if the dealer has bust
			Thread.sleep(3500); //waits
			System.out.println("The dealer has Bust");
			break;  // ends while loop
		}	
		Thread.sleep(2000); //waits
		format1.design1();   // section separator
		Thread.sleep(3000); //waits
	
		int highScore = dealerFinal < playerFinal ? playerFinal : dealerFinal;  // conditional operator to determine if the player or dealer had the highscore and lowscore, to then tell the player the difference in the stats given at end of round
		int lowScore = dealerFinal > playerFinal ? playerFinal : dealerFinal;
		int difference = (highScore - lowScore);
		
		if (dealerFinal > playerFinal) {   // final logic to decide who wins
			System.out.println("The dealer has won the game");
		} else if (dealerFinal < playerFinal) {
			System.out.println("You have won the game");
		} else {
			System.out.println("The game was a tie");
		}
		System.out.println("His score was: " + dealerFinal + " and your score was: " + playerFinal);
		System.out.println("The difference in score was: " + difference);
   }
	format1.design2();   // section separator2
	Thread.sleep(10000);
	clearEndPrompt(0);
}

	public static void clearEndPrompt(int a) throws InterruptedException { // throws inturruptedException is to allow for Thread.sleep (used to give player time to read - waits)	
		System.out.println(" ");		// this recursion is used to "clear" the console after statistics are read, this focuses on the creator names at the end
		if(a<100) {
		a++;
		clearEndPrompt(a);
		}else {
		MainGame test1 = new MainGame();   // calls constants of game from constructor area
		Thread.sleep(3000);  // cleans up game
		System.out.printf("This game was made by: %s, %s, and %s", test1.creator1, test1.creator2, test1.creator3);		// uses printf to keep simple, uses the constants from beginning
		System.exit(0);
	}
	}
}

	