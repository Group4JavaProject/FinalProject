package game;

public class rules {
	
	public void print() {
		System.out.println("These are the game rules: you have 30 seconds to read");
		System.out.println("Blackjack is a game that uses a standard 52-card pack. \n"
				+ "Face cards are worth up to 10.\n"
				+ "The other cards are worth their shown value: 2, 3, 4 etc�\n"
				+ "The goal is to try to draw cards in an attempt to beat the dealer by getting 21 or as close to 21, without going over. \n"
				+ "Going over 21 is known as �busting� or �bust�.\n"
				+ "At the start, a player is dealt 2 cards face-up while the dealer has 1 card face up and one face down.\n"
				+ "Once the cards have been dealt, the player can choose either to hit or stand.\n"
				+ "If the player chooses to stand, the dealer will turn-over their face down card. \n"
				+ "If the dealer�s cards are under 17, they will draw until they either beat the player or �bust�.\n"
				+ "If the player chooses to �hit� instead of �stand�, the dealer will deal them another card.\n"
				+ "The player can continue to hit in an attempt to reach the desired amount or �bust�.\n"
				+ "If a player is dealt a 10 or face card and an Ace it is known as Blackjack. \n"
				+ "for our modifications, the dealer and player can only hold a max of 4 cards each in their hands" 
				+ "modification #2 - All aces = 11" );
		}
	}
