package game;

public class formatting {

	public void design1() {
		System.out.println("----------------------------------------");   // the design used to make the game easier to understand, put in its own class to ease up clutter in the main class
		System.out.println(" ");
	}
	public void design2() {
		System.out.println(" ");
		System.out.println("----------------------------------------");  // secondary design but includes extra space
		System.out.println(" ");
	}
}
