package game;

public class formatting {

	public void design1() {
		System.out.println("----------------------------------------");   // the design used to make the game easier to understand, put in its own class to ease up clutter in the main class
		System.out.println(" ");
	}
}
class formatting1 extends formatting {    // inheritance from the other design method
	public void design2() {
		System.out.println(" ");  // secondary design but includes extra space
		super.design1();		// calls on first format, using design1 as the super to save space since the 2 formats are super similar

	}
}
	
