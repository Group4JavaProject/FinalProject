package game;

import java.util.Random;

public class dealerArray {

	public void dArr() {
		String[] array1 = {"Dave", "Chris", "Anna", "Steven", "Bella"};		// our string array selects from predetermined dealer names to make the game more realistic
		Random dealer = new Random();				// randomizes the value to be picked from the array
		int dealerNum = dealer.nextInt(0, 5);
		switch(dealerNum) {
			case(0):			// uses switch statement to allow for individual responses for each dealer if they get picked (we customized it for the gender to make the game feel more personalized)
				System.out.println(array1[dealerNum] + " is your dealer, he will start your game shortly");
				break;  // breaks statement so that it wont continue multiple times
			case(1):
				System.out.println(array1[dealerNum] + " is your dealer, he will start your game shortly");
				break;  // breaks statement so that it wont continue multiple times
			case(2):
				System.out.println(array1[dealerNum] + " is your dealer, she will start your game shortly");
				break;  // breaks statement so that it wont continue multiple times
			case(3):
				System.out.println(array1[dealerNum] + " is your dealer, he will start your game shortly");
				break;  // breaks statement so that it wont continue multiple times
			case(4):
				System.out.println(array1[dealerNum] + " is your dealer, she will start your game shortly");
				break;  // breaks statement so that it wont continue multiple times
		}	
	}
}
